declare module '*.png';
declare module '*.css';
