import { AppConfig } from "remax/wechat";

const config: AppConfig = {
  pages: ['pages/index/index'],
  window: {
    navigationBarTitleText: '小说',
    navigationBarBackgroundColor: '#55aaff',
  },
  tabBar: {
    color: "#282828",
    selectedColor: "#55aaff",
    backgroundColor: "#EEEEEE",
    list: [
      {
        pagePath: "pages/index/index",
        text: "首页",
        iconPath: "static/tab/index.png",
        selectedIconPath: "static/tab/index1.png"
      },
      {
        pagePath: "pages/index/index",
        text: "男生",
        iconPath: "static/tab/shujia.png",
        selectedIconPath: "static/tab/shujia1.png"
      },
      {
        pagePath: "pages/index/index",
        text: "女生",
        iconPath: "static/tab/fenlei.png",
        selectedIconPath: "static/tab/fenlei1.png"
      },
      {
        pagePath: "pages/index/index",
        text: "出版",
        iconPath: "static/tab/wode.png",
        selectedIconPath: "static/tab/wode1.png"
      },
      {
        pagePath: "pages/index/index",
        text: "排行",
        iconPath: "static/tab/wode.png",
        selectedIconPath: "static/tab/wode1.png"
      }
    ]
  },
};

export default config;
