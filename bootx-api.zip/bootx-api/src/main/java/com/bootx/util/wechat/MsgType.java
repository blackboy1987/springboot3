package com.bootx.util.wechat;

public enum MsgType {
    news,
    music,
    video,
    voice,
    image,
    text,
}
