/**
  * Copyright 2021 json.cn 
  */
package com.bootx.app.question.pojo;

/**
 * Auto-generated: 2021-03-09 14:11:55
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class Answers {

    private String t;
    private String answer;
    private Integer istrue;
    public void setT(String t) {
         this.t = t;
     }
     public String getT() {
         return t;
     }

    public void setAnswer(String answer) {
         this.answer = answer;
     }
     public String getAnswer() {
         return answer;
     }

    public void setIstrue(Integer istrue) {
         this.istrue = istrue;
     }
     public Integer getIstrue() {
         return istrue;
     }

}