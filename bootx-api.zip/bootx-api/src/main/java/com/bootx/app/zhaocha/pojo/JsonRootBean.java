/**
  * Copyright 2021 json.cn 
  */
package com.bootx.app.zhaocha.pojo;

/**
 * Auto-generated: 2021-03-15 15:39:22
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class JsonRootBean {

    private Data data;
    private int code;
    private String msg;
    public void setData(Data data) {
         this.data = data;
     }
     public Data getData() {
         return data;
     }

    public void setCode(int code) {
         this.code = code;
     }
     public int getCode() {
         return code;
     }

    public void setMsg(String msg) {
         this.msg = msg;
     }
     public String getMsg() {
         return msg;
     }

}