
package com.bootx.app.chengyu.dao;

import com.bootx.app.chengyu.entity.Word;
import com.bootx.dao.BaseDao;

/**
 * Dao - 素材目录
 * 
 * @author blackboy
 * @version 1.0
 */
public interface WordDao extends BaseDao<Word, Long> {

}