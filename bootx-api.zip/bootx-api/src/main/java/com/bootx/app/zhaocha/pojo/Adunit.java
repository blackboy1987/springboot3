/**
  * Copyright 2021 json.cn 
  */
package com.bootx.app.zhaocha.pojo;

/**
 * Auto-generated: 2021-03-15 15:39:22
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class Adunit {

    private String banner;
    private String chaping;
    private String video;
    public void setBanner(String banner) {
         this.banner = banner;
     }
     public String getBanner() {
         return banner;
     }

    public void setChaping(String chaping) {
         this.chaping = chaping;
     }
     public String getChaping() {
         return chaping;
     }

    public void setVideo(String video) {
         this.video = video;
     }
     public String getVideo() {
         return video;
     }

}