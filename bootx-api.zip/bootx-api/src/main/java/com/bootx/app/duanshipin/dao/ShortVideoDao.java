
package com.bootx.app.duanshipin.dao;

import com.bootx.app.duanshipin.entity.ShortVideo;
import com.bootx.dao.BaseDao;

/**
 * Dao - 素材目录
 * 
 * @author blackboy
 * @version 1.0
 */
public interface ShortVideoDao extends BaseDao<ShortVideo, Long> {

}