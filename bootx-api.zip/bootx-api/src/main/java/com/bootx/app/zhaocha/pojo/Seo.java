/**
  * Copyright 2021 json.cn 
  */
package com.bootx.app.zhaocha.pojo;

/**
 * Auto-generated: 2021-03-15 15:39:22
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class Seo {

    private String seo_index;
    private String seo_game;
    private String seo_win;
    private String seo_fail;
    private String seo_paiwei;
    private String seo_paiwei_result;
    public void setSeo_index(String seo_index) {
         this.seo_index = seo_index;
     }
     public String getSeo_index() {
         return seo_index;
     }

    public void setSeo_game(String seo_game) {
         this.seo_game = seo_game;
     }
     public String getSeo_game() {
         return seo_game;
     }

    public void setSeo_win(String seo_win) {
         this.seo_win = seo_win;
     }
     public String getSeo_win() {
         return seo_win;
     }

    public void setSeo_fail(String seo_fail) {
         this.seo_fail = seo_fail;
     }
     public String getSeo_fail() {
         return seo_fail;
     }

    public void setSeo_paiwei(String seo_paiwei) {
         this.seo_paiwei = seo_paiwei;
     }
     public String getSeo_paiwei() {
         return seo_paiwei;
     }

    public void setSeo_paiwei_result(String seo_paiwei_result) {
         this.seo_paiwei_result = seo_paiwei_result;
     }
     public String getSeo_paiwei_result() {
         return seo_paiwei_result;
     }

}