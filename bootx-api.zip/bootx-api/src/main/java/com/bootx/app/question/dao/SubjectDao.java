
package com.bootx.app.question.dao;

import com.bootx.app.question.entity.Subject;
import com.bootx.app.yunxiaocha.entity.Order;
import com.bootx.dao.BaseDao;

/**
 * Dao - 素材目录
 * 
 * @author blackboy
 * @version 1.0
 */
public interface SubjectDao extends BaseDao<Subject, Long> {

}