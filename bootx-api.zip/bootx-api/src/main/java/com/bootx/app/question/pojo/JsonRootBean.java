/**
  * Copyright 2021 json.cn 
  */
package com.bootx.app.question.pojo;

/**
 * Auto-generated: 2021-03-09 14:11:55
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class JsonRootBean {

    private String result;
    private long time;
    private Question question;
    public void setResult(String result) {
         this.result = result;
     }
     public String getResult() {
         return result;
     }

    public void setTime(long time) {
         this.time = time;
     }
     public long getTime() {
         return time;
     }

    public void setQuestion(Question question) {
         this.question = question;
     }
     public Question getQuestion() {
         return question;
     }

}