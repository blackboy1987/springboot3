
package com.bootx.app.duanshipin.dao;

import com.bootx.app.duanshipin.entity.ShortVideoChannel;
import com.bootx.dao.BaseDao;

/**
 * Dao - 素材目录
 * 
 * @author blackboy
 * @version 1.0
 */
public interface ShortVideoChannelDao extends BaseDao<ShortVideoChannel, Long> {

}