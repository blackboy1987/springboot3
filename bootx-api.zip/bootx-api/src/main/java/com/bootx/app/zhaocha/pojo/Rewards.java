/**
  * Copyright 2021 json.cn 
  */
package com.bootx.app.zhaocha.pojo;

/**
 * Auto-generated: 2021-03-15 15:39:22
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class Rewards {

    private int open;
    private String unit;
    private int max_unit;
    private String img;
    private String msg;
    public void setOpen(int open) {
         this.open = open;
     }
     public int getOpen() {
         return open;
     }

    public void setUnit(String unit) {
         this.unit = unit;
     }
     public String getUnit() {
         return unit;
     }

    public void setMax_unit(int max_unit) {
         this.max_unit = max_unit;
     }
     public int getMax_unit() {
         return max_unit;
     }

    public void setImg(String img) {
         this.img = img;
     }
     public String getImg() {
         return img;
     }

    public void setMsg(String msg) {
         this.msg = msg;
     }
     public String getMsg() {
         return msg;
     }

}