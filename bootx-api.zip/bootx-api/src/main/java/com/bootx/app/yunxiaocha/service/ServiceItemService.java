
package com.bootx.app.yunxiaocha.service;

import com.bootx.app.yunxiaocha.entity.ServiceItem;
import com.bootx.service.BaseService;

/**
 * Service - 插件
 * 
 * @author blackboy
 * @version 1.0
 */
public interface ServiceItemService extends BaseService<ServiceItem,Long> {

}