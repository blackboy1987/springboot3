
package com.bootx.app.yunxiaocha.dao;

import com.bootx.app.yunxiaocha.entity.ServiceItem;
import com.bootx.dao.BaseDao;
import com.bootx.entity.App;

/**
 * Dao - 素材目录
 * 
 * @author blackboy
 * @version 1.0
 */
public interface ServiceItemDao extends BaseDao<ServiceItem, Long> {

}