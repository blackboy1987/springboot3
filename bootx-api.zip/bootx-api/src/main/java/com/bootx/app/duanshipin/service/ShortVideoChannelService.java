
package com.bootx.app.duanshipin.service;

import com.bootx.app.duanshipin.entity.ShortVideoChannel;
import com.bootx.service.BaseService;

/**
 * Service - 插件
 * 
 * @author blackboy
 * @version 1.0
 */
public interface ShortVideoChannelService extends BaseService<ShortVideoChannel,Long> {

}