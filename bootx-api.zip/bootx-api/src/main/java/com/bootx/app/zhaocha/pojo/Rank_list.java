/**
  * Copyright 2021 json.cn 
  */
package com.bootx.app.zhaocha.pojo;

/**
 * Auto-generated: 2021-03-15 15:39:22
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class Rank_list {

    private int rank;
    private String img;
    private String rank_name;
    private String value_title;
    private String rank_img;
    public void setRank(int rank) {
         this.rank = rank;
     }
     public int getRank() {
         return rank;
     }

    public void setImg(String img) {
         this.img = img;
     }
     public String getImg() {
         return img;
     }

    public void setRank_name(String rank_name) {
         this.rank_name = rank_name;
     }
     public String getRank_name() {
         return rank_name;
     }

    public void setValue_title(String value_title) {
         this.value_title = value_title;
     }
     public String getValue_title() {
         return value_title;
     }

    public void setRank_img(String rank_img) {
         this.rank_img = rank_img;
     }
     public String getRank_img() {
         return rank_img;
     }

}