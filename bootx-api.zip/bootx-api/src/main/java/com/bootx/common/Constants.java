package com.bootx.common;

public final class Constants {

    public static final String RESOURCEURL="https://bootx-zhaocha.oss-cn-hangzhou.aliyuncs.com/";

    public static final String MOVIE_INDEX = "movie";


}
