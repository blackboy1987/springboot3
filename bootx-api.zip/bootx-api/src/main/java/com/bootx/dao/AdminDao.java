
package com.bootx.dao;

import com.bootx.entity.Admin;

/**
 * Dao - 管理员
 * 
 * @author 好源++ Team
 * @version 6.1
 */
public interface AdminDao extends BaseDao<Admin, Long> {

}