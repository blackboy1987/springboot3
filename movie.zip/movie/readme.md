1. appCode 和 appToken 修改
    涉及到的文件
        main.js  第30行
        vendor.js 第54行
2. 接口地址修改：main.js  148行